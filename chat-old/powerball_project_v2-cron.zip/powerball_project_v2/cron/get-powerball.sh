#!/bin/bash
# get-powerball.sh — Download the latest Florida Powerball results PDF.
# Overwrites pb.pdf in /var/local/powerball and keeps dated history copies.
# Requires: wget

set -euo pipefail

BASE_DIR="/var/local/powerball"
HIST_DIR="$BASE_DIR/history"
URL="https://files.floridalottery.com/exptkt/pb.pdf"
TODAY=$(date +%Y-%m-%d)
OUTFILE="$BASE_DIR/pb.pdf"
HISTFILE="$HIST_DIR/pb-$TODAY.pdf"
LOGFILE="$BASE_DIR/cron.log"

mkdir -p "$HIST_DIR"

# Download directly to pb.pdf
if wget -q -O "$OUTFILE" "$URL"; then
  if [ -s "$OUTFILE" ]; then
    cp -f "$OUTFILE" "$HISTFILE"
    echo "$(date '+%F %T') OK: downloaded $URL -> $OUTFILE" >> "$LOGFILE"
  else
    echo "$(date '+%F %T') ERROR: empty file after download from $URL" >> "$LOGFILE"
    exit 1
  fi
else
  echo "$(date '+%F %T') ERROR: wget failed for $URL" >> "$LOGFILE"
  exit 1
fi
