# Cron setup

Install:
```bash
sudo install -m 755 cron/get-powerball.sh /usr/local/bin/get-powerball.sh
sudo install -m 644 cron/powerball.cron.d /etc/cron.d/powerball
sudo mkdir -p /var/local/powerball/history
sudo chown -R root:root /var/local/powerball
sudo systemctl reload cron  # or: sudo service cron reload
```
